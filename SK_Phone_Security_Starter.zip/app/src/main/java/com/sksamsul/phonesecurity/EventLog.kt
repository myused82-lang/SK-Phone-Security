package com.sksamsul.phonesecurity

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EventLog {
    private const val PREFS = "security_events"
    private const val KEY = "events"

    fun add(context: Context, message: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(KEY, "") ?: ""
        val updated = "$stamp — $message\n" + old
        prefs.edit().putString(KEY, updated.take(20000)).apply()
    }

    fun read(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "এখনও কোনো ঘটনা সংরক্ষিত হয়নি।") ?: "এখনও কোনো ঘটনা সংরক্ষিত হয়নি।"

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
