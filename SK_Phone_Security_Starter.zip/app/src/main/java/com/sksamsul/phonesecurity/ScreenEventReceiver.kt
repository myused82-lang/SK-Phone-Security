package com.sksamsul.phonesecurity

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_ON -> EventLog.add(context, "স্ক্রিন চালু হয়েছে")
            Intent.ACTION_SCREEN_OFF -> EventLog.add(context, "স্ক্রিন বন্ধ হয়েছে")
            Intent.ACTION_BOOT_COMPLETED -> EventLog.add(context, "ফোন চালু হয়েছে")
        }
    }
}
