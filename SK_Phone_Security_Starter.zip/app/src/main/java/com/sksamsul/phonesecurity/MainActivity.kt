package com.sksamsul.phonesecurity

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "SK Phone Security"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val note = TextView(this).apply {
            text = "আপনার ফোনের নিরাপত্তার ঘটনার তালিকা\n\nভুল PIN শনাক্ত করতে নিচের বোতাম দিয়ে Device Admin চালু করুন।"
            textSize = 16f
            setPadding(0, 20, 0, 16)
        }
        val adminButton = Button(this).apply {
            text = "Device Admin চালু করুন"
            setOnClickListener { requestDeviceAdmin() }
        }
        val refreshButton = Button(this).apply {
            text = "ঘটনার তালিকা রিফ্রেশ"
            setOnClickListener { refreshLog() }
        }
        val clearButton = Button(this).apply {
            text = "ঘটনার তালিকা মুছুন"
            setOnClickListener {
                EventLog.clear(this@MainActivity)
                refreshLog()
            }
        }
        logView = TextView(this).apply { textSize = 14f; setPadding(0, 18, 0, 0) }
        root.addView(title)
        root.addView(note)
        root.addView(adminButton)
        root.addView(refreshButton)
        root.addView(clearButton)
        val scroll = ScrollView(this)
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshLog()
    }

    private fun requestDeviceAdmin() {
        val component = ComponentName(this, SecurityAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "ভুল PIN/পাসওয়ার্ড দিয়ে আনলক করার চেষ্টার তথ্য সংরক্ষণের জন্য।")
        }
        startActivity(intent)
    }

    private fun refreshLog() {
        logView.text = EventLog.read(this)
    }
}
