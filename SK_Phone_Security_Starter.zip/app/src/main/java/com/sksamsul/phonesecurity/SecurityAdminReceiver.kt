package com.sksamsul.phonesecurity

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class SecurityAdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        EventLog.add(context, "ভুল PIN/পাসওয়ার্ড দিয়ে আনলক করার চেষ্টা")
    }
}
